document.addEventListener('DOMContentLoaded', () => {
    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('nav ul li a');

    navLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const section = document.querySelector(this.getAttribute('href'));
            window.scroll({
                top: section.offsetTop,
                behavior: 'smooth'
            });
        });
    });

    // Add animations to sections on scroll
    const sections = document.querySelectorAll('section');
    const options = {
        threshold: 0.5
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, options);

    sections.forEach(section => {
        observer.observe(section);
    });

    // Adding parallax effect to sections with the 'parallax' class
    window.addEventListener('scroll', function() {
        const parallaxElements = document.querySelectorAll('.parallax');
        parallaxElements.forEach(element => {
            let scrollPosition = window.scrollY;
            element.style.backgroundPositionY = `${scrollPosition * 0.5}px`;
        });
    });
});
// scripts.js

// Liste des images de fond
var backgrounds = [
    "{% static 'img/PNG.png' %}",
    "{% static 'img/PNG.png' %}",
    // Ajoute d'autres images de fond ici si nécessaire
];

// Fonction pour changer l'image de fond
function changeBackground() {
    var randomIndex = Math.floor(Math.random() * backgrounds.length);
    var selectedBackground = backgrounds[randomIndex];
    document.body.style.backgroundImage = "url('" + selectedBackground + "')";
}

// Appel initial pour changer le fond au chargement de la page
changeBackground();

// Optionnel : Changer le fond à intervalle régulier (par exemple toutes les 10 secondes)
setInterval(changeBackground, 4000); // 10000 milliseconds = 10 seconds
