from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import Paginator
from django.core.mail import send_mail
from django.conf import settings
from .forms import ContactForm
from .models import Product
from django.contrib import messages
from django.http import HttpResponse
from django.views.decorators.http import require_POST

def index(request):
    return render(request, 'index.html')

def product(request):
    query = request.GET.get('q')
    category = request.GET.get('category', '')
    all_product = Product.objects.all()

    if query:
        all_product = all_product.filter(name__icontains=query)

    if category:
        all_product = all_product.filter(categorie=category)

    paginator = Paginator(all_product, 10) # 10 est le maximum de produits à afficher par page

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    categories = Product.objects.values_list('categorie', flat=True).distinct()

    return render(request, 'product.html', {'page_obj': page_obj, 'query': query, 'categories': categories, 'selected_category': category})

def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart = request.session.get('cart', {})
    
    if str(product_id) in cart:
        cart[str(product_id)]['quantity'] += 1
    else:
        cart[str(product_id)] = {
            'product_name': product.nom,
            'price': str(product.prix),
            'quantity': 1
        }
    
    request.session['cart'] = cart
    messages.success(request, f"{product.nom} a été ajouté à votre panier.")
    return redirect('view_cart')

def view_cart(request):
    cart = request.session.get('cart', {})
    return render(request, 'cart.html', {'cart': cart})

def remove_from_cart(request, product_id):
    cart = request.session.get('cart', {})
    if str(product_id) in cart:
        del cart[str(product_id)]
        request.session['cart'] = cart
        messages.success(request, "L'article a été retiré de votre panier.")
    
    return redirect('view_cart')

def checkout(request):
    cart = request.session.get('cart', {})
    # Logique de traitement du paiement ici

    # Vider le panier après l'achat
    request.session['cart'] = {}
    return render(request, 'checkout.html', {'cart': cart})

def about(request):
    return render(request, 'about.html')

def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            
            # Envoyer un email
            send_mail(
                f'Message de {name}',
                message,
                email,
                [settings.DEFAULT_FROM_EMAIL],
            )
            
            return render(request, 'contact.html', {'form': form, 'success': True})
    else:
        form = ContactForm()
    
    return render(request, 'contact.html', {'form': form})

def sitemap_view(request):
    return render(request, 'sitemap.html')

def terms_conditions(request):
    return render(request, 'terms_conditions.html')

def privacy_policy(request):
    return render(request, 'privacy_policy.html')


def blog(request):
    return render(request, 'blog.html')

def payment_page(request):
    return render(request, 'payment_page.html')

@require_POST
def add_to_cart_and_redirect(request):
    item_id = request.POST.get('item_id')
    # Logique pour ajouter l'article au panier et rediriger vers la page de paiement
    return redirect('payment_page')  # Assurez-vous que 'payment_page' est défini dans vos URLs

def send_message(request):
    return HttpResponse("Message envoyé")
