
from django import forms

class ContactForm(forms.Form):
    name = forms.CharField(max_length=100, label='Name', widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your name'}))
    lastname = forms.CharField(max_length=100, label='Last Name', widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your last name'}))
    email = forms.EmailField(label='Email', widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter your email'}))
    message = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Enter your message'}), label='Message')

    # Définir des labels et des placeholders personnalisés pour chaque champ
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].label = 'Name'
        self.fields['lastname'].label = 'Last Name'
        self.fields['email'].label = 'Email'
        self.fields['message'].label = 'Message'

    # Validation personnalisée (facultatif)
    def clean_email(self):
        email = self.cleaned_data.get('email')
        # Valider l'email selon vos besoins
        return email


