from django.urls import path
from .views import index, product, about, contact, add_to_cart, view_cart, checkout, send_message, remove_from_cart, add_to_cart_and_redirect, payment_page, privacy_policy, terms_conditions, sitemap_view

urlpatterns = [
    path('', index, name='index'),
    path('product/', product, name='product'),
    path('about/', about, name='about'),
    path('contact/', contact, name='contact'),
    path('add_to_cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('cart/', view_cart, name='cart'),
    path('checkout/', checkout, name='checkout'),
    path('send_message/', send_message, name='send_message'),
    path('view-cart/', view_cart, name='view_cart'),
    path('remove-from-cart/<int:product_id>/', remove_from_cart, name='remove_from_cart'),
    path('add_to_cart_and_redirect/', add_to_cart_and_redirect, name='add_to_cart_and_redirect'),
    path('payment/', payment_page, name='payment_page'),
    path('privacy-policy/', privacy_policy, name='privacy_policy'),
    path('terms_conditions/', terms_conditions, name='terms_conditions'),
    path('sitemap/', sitemap_view, name='sitemap'),
    path('politique-de-confidentialité/', privacy_policy, name='politique_confidentialite'),
    path('blog/', privacy_policy, name='blog'),
    
]
